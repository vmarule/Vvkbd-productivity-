VVKBD Productivity v2

New in v2:
- Start date/time and end date/time for tasks
- Editable tasks
- Task reminders
- Repeat options
- Editable goals
- Goal start and target dates
- Goal progress
- Goal reminders
- Calendar/timeline view
- Upcoming reminders view
- Local/offline storage
- VVKBD branding

This is an Android-friendly PWA build. To install as an app, serve the files over HTTPS and open the site in Chrome, then choose Add to Home screen / Install app.
